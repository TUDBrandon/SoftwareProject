<?php
session_start();
require_once '../includes/common.php';

$cart = $_SESSION['cart'] ?? [];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Your Shopping Cart</title>
    <link rel="stylesheet" href="css/style.css?v=<?php echo time(); ?>">
</head>
<body>
    <?php echo generate_navbar('cart'); ?>

    <main>
        <h1>Your Shopping Cart</h1>
        <?php if (empty($cart)): ?>
            <p>Your cart is currently empty.</p>
        <?php else: ?>
            <div class="cart-items">
                <?php foreach ($cart as $index => $item): ?>
                    <div class="cart-item">
                        <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" style="width:100px;">
                        <div>
                            <h3><?php echo htmlspecialchars($item['name']); ?></h3>
                            <p>Category: <?php echo htmlspecialchars($item['category']); ?></p>
                            <p>Price: €<?php echo htmlspecialchars($item['price']); ?></p>

                            <!-- Remove button -->
                            <form action="remove_from_cart.php" method="POST" style="margin-top: 10px;">
                                <input type="hidden" name="index" value="<?php echo $index; ?>">
                                <button type="submit" class="remove-button">Remove</button>
                            </form>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>
</body>
</html>
